import React from 'react'
import LandingPage from '../Pages/LandingPage.jsx'

function App() {
  return <LandingPage />
}

export default App
