import React from "react";
import { motion } from "framer-motion";

export default function LogoCloud() {
  const logos = [
    {
      src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68192c2d8b128ca183fad0a9/8322a56e3_positivo.png",
      alt: "Positivo Tecnologia"
    },
    {
      src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68192c2d8b128ca183fad0a9/b786b42c9_tupi.png",
      alt: "Tupi"
    }
  ];

  return (
    <section className="py-16 bg-white border-y border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <p className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-8">
            Empresas que já contrataram 10x mais rápido
          </p>
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-16">
            {logos.map((logo, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, duration: 0.5 }}
                className="grayscale hover:grayscale-0 transition-all duration-300"
              >
                <img 
                  src={logo.src} 
                  alt={logo.alt}
                  className="h-12 md:h-16 object-contain"
                />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
