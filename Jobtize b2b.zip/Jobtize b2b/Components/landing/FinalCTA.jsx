import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle, Clock, Shield } from "lucide-react";

export default function FinalCTA() {
  return (
    <section className="py-20 md:py-32 bg-gradient-to-br from-[#2C3E50] via-[#34495E] to-[#2C3E50] relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-64 h-64 bg-[#4A90E2] rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-[#FF6B35] rounded-full blur-3xl" />
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-6">
            <Clock className="w-4 h-4 text-[#FF6B35]" />
            <span className="text-sm font-medium text-white">Tempo limitado: Acesso prioritário</span>
          </div>

          {/* Headline */}
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Pronto para contratar os melhores talentos{" "}
            <span className="bg-gradient-to-r from-[#4A90E2] to-[#FF6B35] bg-clip-text text-transparent">
              10x mais rápido?
            </span>
          </h2>

          {/* Sub-headline */}
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            Pare de perder tempo com triagem manual. Veja como o futuro do recrutamento funciona na prática.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <a
              href="https://wa.me/5511987461094?text=Quero%20colocar%20minha%20empresa%20no%20futuro%20do%20recrutamento"
              target="_blank"
              rel="noopener noreferrer"
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full bg-gradient-to-r from-[#FF6B35] to-[#FF8C42] text-white px-8 py-5 rounded-xl font-bold text-lg shadow-2xl hover:shadow-orange-500/50 transition-all duration-300 flex items-center justify-center gap-2 group"
              >
                Agendar Demo Rápida
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </motion.button>
            </a>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white/10 backdrop-blur-sm border-2 border-white/30 text-white px-8 py-5 rounded-xl font-bold text-lg hover:bg-white/20 transition-all duration-300"
            >
              Ver Calculadora de ROI
            </motion.button>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            {[
              { icon: CheckCircle, text: "Demo em 15 minutos" },
              { icon: Shield, text: "Sem compromisso" },
              { icon: Clock, text: "Setup em 24 horas" }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="flex items-center justify-center gap-3 text-white/90"
              >
                <item.icon className="w-5 h-5 text-[#4A90E2]" />
                <span className="text-sm font-medium">{item.text}</span>
              </motion.div>
            ))}
          </div>

          {/* Urgency Text */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="text-gray-400 text-sm mt-12"
          >
            🔥 Apenas <strong className="text-[#FF6B35]">7 vagas</strong> restantes para onboarding premium em Janeiro
          </motion.p>
        </motion.div>
      </div>
    </section>
  );
}
