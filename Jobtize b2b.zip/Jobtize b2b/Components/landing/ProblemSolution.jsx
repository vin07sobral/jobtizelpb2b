import React from "react";
import { motion } from "framer-motion";
import { AlertCircle, Bot, Sparkles } from "lucide-react";

export default function ProblemSolution() {
  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Problem */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-red-50 border border-red-200 rounded-full px-4 py-2 mb-6">
              <AlertCircle className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-900">O Problema</span>
            </div>
            
            <h3 className="text-3xl md:text-4xl font-bold text-[#2C3E50] mb-6">
              Processos manuais estão custando seus melhores candidatos?
            </h3>
            
            <p className="text-lg text-gray-600 leading-relaxed mb-6">
              Triagens lentas, feedbacks perdidos e custos de oportunidade de vagas abertas estão drenando seu orçamento e frustrando seu time.
            </p>
            
            <p className="text-lg text-gray-600 leading-relaxed font-medium">
              O talento que você quer <span className="text-red-600">aceitou outra oferta ontem</span>.
            </p>

            {/* Pain Points */}
            <div className="mt-8 space-y-3">
              {[
                "Semanas perdidas em triagem manual",
                "Candidatos de qualidade perdidos para concorrentes",
                "Time de RH sobrecarregado com tarefas operacionais",
                "Custos crescentes por dia de vaga aberta"
              ].map((pain, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-gray-700">{pain}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Solution */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-50 to-green-50 border border-blue-200 rounded-full px-4 py-2 mb-6">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-900">A Solução</span>
            </div>
            
            <h3 className="text-3xl md:text-4xl font-bold text-[#2C3E50] mb-6">
              Jobtize: O primeiro{" "}
              <span className="bg-gradient-to-r from-[#4A90E2] to-[#FF6B35] bg-clip-text text-transparent">
                Sistema Agêntico
              </span>{" "}
              que recruta por você.
            </h3>
            
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              Nosso sistema agêntico usa <strong>Machine Learning de precisão</strong> para encontrar, avaliar e engajar os candidatos ideais 24/7. Deixe a IA cuidar do operacional para que seu time foque no estratégico.
            </p>

            {/* Solution Benefits */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 border-2 border-blue-200">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-[#4A90E2] to-[#5BA3F5] rounded-xl flex items-center justify-center">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-[#2C3E50]">Como funciona</h4>
                  <p className="text-sm text-gray-600">Automação inteligente de ponta a ponta</p>
                </div>
              </div>
              
              <div className="space-y-4">
                {[
                  { step: "01", text: "Você abre a vaga em 30 segundos via chat" },
                  { step: "02", text: "IA busca e analisa milhares de candidatos" },
                  { step: "03", text: "Você recebe os 5 melhores matches ranqueados" },
                  { step: "04", text: "IA gerencia feedbacks e comunicação automaticamente" }
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center font-bold text-[#4A90E2] text-sm shadow-sm">
                      {item.step}
                    </div>
                    <p className="text-gray-700 pt-1">{item.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
