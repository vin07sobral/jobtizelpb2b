import React from "react";
import { motion } from "framer-motion";
import { MessageSquare, Target, TrendingDown, Heart } from "lucide-react";

export default function BenefitsGrid() {
  const benefits = [
    {
      icon: MessageSquare,
      title: "Abra vagas em 30 segundos, direto do seu chat.",
      description: "Integre o Jobtize ao Slack ou Teams. Apenas envie 'Contratar Engenheiro de Software Pleno' e nosso agente inicia o processo, cria a descrição e começa a busca imediatamente.",
      gradient: "from-blue-500 to-cyan-500",
      bgGradient: "from-blue-50 to-cyan-50"
    },
    {
      icon: Target,
      title: "Elimine 90% do tempo gasto em triagem.",
      description: "Nosso algoritmo de precisão analisa milhares de pontos de dados para entregar apenas os 5 melhores candidatos, ranqueados e com justificativa, direto para sua aprovação.",
      gradient: "from-purple-500 to-pink-500",
      bgGradient: "from-purple-50 to-pink-50"
    },
    {
      icon: TrendingDown,
      title: "Diga adeus ao 'custo de oportunidade'.",
      description: "Cada dia com uma vaga aberta custa dinheiro. Ao reduzir seu tempo de contratação em 90% e seu custo em 60%, o Jobtize se paga no primeiro mês.",
      gradient: "from-orange-500 to-red-500",
      bgGradient: "from-orange-50 to-red-50"
    },
    {
      icon: Heart,
      title: "Fortaleça sua marca empregadora sem esforço.",
      description: "Mantenha 100% dos candidatos informados com feedbacks automatizados e personalizados em cada etapa, garantindo uma experiência positiva mesmo para quem não for selecionado.",
      gradient: "from-green-500 to-emerald-500",
      bgGradient: "from-green-50 to-emerald-50"
    }
  ];

  return (
    <section className="py-20 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-[#2C3E50] mb-4">
            Por que líderes de RH escolhem o Jobtize
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transforme seu processo de recrutamento com benefícios tangíveis desde o dia 1
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="group"
            >
              <div className={`relative bg-gradient-to-br ${benefit.bgGradient} rounded-2xl p-8 border-2 border-gray-200 hover:border-transparent hover:shadow-2xl transition-all duration-300`}>
                {/* Icon */}
                <div className={`w-16 h-16 bg-gradient-to-r ${benefit.gradient} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <benefit.icon className="w-8 h-8 text-white" />
                </div>

                {/* Content */}
                <h4 className="text-2xl font-bold text-[#2C3E50] mb-4">
                  {benefit.title}
                </h4>
                <p className="text-gray-600 leading-relaxed">
                  {benefit.description}
                </p>

                {/* Decorative Element */}
                <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${benefit.gradient} opacity-5 rounded-full blur-2xl -z-10 group-hover:opacity-10 transition-opacity duration-300`} />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-center mt-16"
        >
          <p className="text-lg text-gray-600 mb-6">
            Pronto para ver o Jobtize em ação?
          </p>
          <a
            href="https://wa.me/5511987461094?text=Quero%20colocar%20minha%20empresa%20no%20futuro%20do%20recrutamento"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-gradient-to-r from-[#FF6B35] to-[#FF8C42] text-white px-8 py-4 rounded-lg font-semibold text-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            Agendar Demo Rápida →
          </a>
        </motion.div>
      </div>
    </section>
  );
}
