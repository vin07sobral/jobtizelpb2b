import React from "react";
import { motion } from "framer-motion";
import { Quote, Star } from "lucide-react";

export default function Testimonial() {
  return (
    <section className="py-20 md:py-32 bg-gradient-to-br from-gray-50 via-blue-50 to-gray-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative"
        >
          {/* Quote Icon */}
          <div className="absolute -top-6 -left-4 md:-left-12">
            <div className="w-20 h-20 bg-gradient-to-r from-[#4A90E2] to-[#FF6B35] rounded-full flex items-center justify-center opacity-20">
              <Quote className="w-10 h-10 text-white" />
            </div>
          </div>

          {/* Testimonial Card */}
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-2xl border border-gray-200 relative">
            {/* Stars */}
            <div className="flex gap-1 mb-6">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
              ))}
            </div>

            {/* Quote */}
            <blockquote className="text-2xl md:text-3xl font-medium text-[#2C3E50] leading-relaxed mb-8">
              "Reduzimos nosso tempo de fechamento de vaga de{" "}
              <span className="text-red-600 line-through">45 dias</span> para{" "}
              <span className="bg-gradient-to-r from-[#4A90E2] to-[#FF6B35] bg-clip-text text-transparent font-bold">
                5 dias
              </span>
              . O Jobtize mudou o jogo para nós. Finalmente conseguimos focar em estratégia ao invés de operacional."
            </blockquote>

            {/* Author */}
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-r from-[#4A90E2] to-[#5BA3F5] rounded-full flex items-center justify-center text-white font-bold text-xl">
                RC
              </div>
              <div>
                <p className="font-bold text-lg text-[#2C3E50]">Renata Costa</p>
                <p className="text-gray-600">Head de Gente & Gestão, TechFlow Solutions</p>
              </div>
            </div>

            {/* Stats Badge */}
            <div className="absolute -bottom-6 right-8 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-full shadow-lg">
              <p className="text-sm font-bold">ROI de 420% no 1º trimestre</p>
            </div>
          </div>

          {/* Background Decoration */}
          <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-r from-orange-400 to-pink-400 rounded-full blur-3xl opacity-20 -z-10" />
        </motion.div>

        {/* Additional Social Proof */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="grid grid-cols-3 gap-8 mt-20 text-center"
        >
          <div>
            <p className="text-4xl font-bold bg-gradient-to-r from-[#4A90E2] to-[#FF6B35] bg-clip-text text-transparent mb-2">
              500+
            </p>
            <p className="text-gray-600">Vagas preenchidas</p>
          </div>
          <div>
            <p className="text-4xl font-bold bg-gradient-to-r from-[#4A90E2] to-[#FF6B35] bg-clip-text text-transparent mb-2">
              98%
            </p>
            <p className="text-gray-600">Taxa de satisfação</p>
          </div>
          <div>
            <p className="text-4xl font-bold bg-gradient-to-r from-[#4A90E2] to-[#FF6B35] bg-clip-text text-transparent mb-2">
              4.5x
            </p>
            <p className="text-gray-600">Mais rápido</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
