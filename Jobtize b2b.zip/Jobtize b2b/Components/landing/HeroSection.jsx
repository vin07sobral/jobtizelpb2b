import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Zap, TrendingDown } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-400/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-orange-400/20 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Copy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-50 to-orange-50 border border-blue-200 rounded-full px-4 py-2 mb-6"
            >
              <Sparkles className="w-4 h-4 text-[#FF6B35]" />
              <span className="text-sm font-medium text-[#2C3E50]">Tecnologia Agentic AI</span>
            </motion.div>

            {/* H1 */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#2C3E50] leading-tight mb-6">
              Contrate os melhores talentos.{" "}
              <span className="bg-gradient-to-r from-[#4A90E2] to-[#FF6B35] bg-clip-text text-transparent">
                Em dias, não em meses.
              </span>
            </h1>

            {/* H2 */}
            <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
              Reduza em <strong className="text-[#FF6B35]">60% seu custo</strong> por contratação e acelere seu processo de R&S em{" "}
              <strong className="text-[#4A90E2]">90%</strong> com o sistema agêntico do Jobtize.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
                <div className="flex items-center gap-2 text-green-600 mb-1">
                  <TrendingDown className="w-5 h-5" />
                  <span className="text-3xl font-bold">60%</span>
                </div>
                <p className="text-sm text-gray-600">Redução de custos</p>
              </div>
              <div className="bg-white rounded-xl p-4 shadow-lg border border-gray-100">
                <div className="flex items-center gap-2 text-blue-600 mb-1">
                  <Zap className="w-5 h-5" />
                  <span className="text-3xl font-bold">90%</span>
                </div>
                <p className="text-sm text-gray-600">Mais rápido</p>
              </div>
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="https://wa.me/5511987461094?text=Quero%20colocar%20minha%20empresa%20no%20futuro%20do%20recrutamento"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center bg-gradient-to-r from-[#FF6B35] to-[#FF8C42] hover:shadow-xl text-white text-lg px-8 py-4 rounded-lg font-semibold group transition-all"
              >
                Ver o Jobtize em Ação
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <button className="inline-flex items-center justify-center text-lg px-8 py-4 rounded-lg border-2 border-gray-300 hover:bg-gray-50 font-semibold transition-all">
                Falar com Especialista
              </button>
            </div>

            {/* Trust Line */}
            <p className="text-sm text-gray-500 mt-6">
              ✓ Sem cartão de crédito • ✓ Demo em 15 minutos • ✓ ROI garantido
            </p>
          </motion.div>

          {/* Right Column - Visual */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="relative"
          >
            <div className="relative bg-white rounded-2xl shadow-2xl p-8 border border-gray-200">
              {/* Dashboard Mockup */}
              <div className="space-y-4">
                {/* Match Score Card */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 border-2 border-green-200">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-medium text-gray-600">Jobtize Score</span>
                    <div className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                      98%
                    </div>
                  </div>
                  <h3 className="font-semibold text-lg text-gray-900 mb-2">Maria Silva</h3>
                  <p className="text-sm text-gray-600 mb-4">Engenheira de Software Sênior</p>
                  
                  {/* Individual Scores */}
                  <div className="space-y-2 mb-4 pb-4 border-b border-green-200">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-600">Cultural Fit</span>
                      <span className="font-semibold text-gray-900">96%</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-600">Experience</span>
                      <span className="font-semibold text-gray-900">99%</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-600">Degree</span>
                      <span className="font-semibold text-gray-900">98%</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-gray-600">Technical Evaluation</span>
                      <span className="font-semibold text-gray-900">99%</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">React</span>
                    <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">Node.js</span>
                    <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">AWS</span>
                  </div>
                </div>

                {/* Time to Hire Chart - Horizontal Bars */}
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border-2 border-blue-200">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-medium text-gray-600">Tempo para Contratar</span>
                    <div className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                      -90%
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    {/* Before Bar */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-gray-600">Antes</span>
                        <span className="text-sm font-bold text-gray-900">40 dias</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: "100%" }}
                          transition={{ duration: 1, delay: 0.5 }}
                          className="bg-gradient-to-r from-gray-400 to-gray-500 h-3 rounded-full"
                        />
                      </div>
                    </div>

                    {/* After Bar */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-gray-600">Com Jobtize</span>
                        <span className="text-sm font-bold text-[#4A90E2]">4 dias</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: "10%" }}
                          transition={{ duration: 1, delay: 0.8 }}
                          className="bg-gradient-to-r from-[#4A90E2] to-[#5BA3F5] h-3 rounded-full shadow-lg"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Bottom Emphasis */}
                  <div className="mt-4 pt-4 border-t border-blue-200">
                    <p className="text-xs text-center text-gray-600">
                      <span className="font-bold text-[#4A90E2]">10x mais rápido</span> que o processo tradicional
                    </p>
                  </div>
                </div>
              </div>

              {/* Floating Badge */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -top-4 -right-4 bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2 rounded-full shadow-lg text-sm font-bold"
              >
                🚀 IA em ação
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
