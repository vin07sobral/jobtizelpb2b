import React from "react";
import HeroSection from "../Components/landing/HeroSection";
import LogoCloud from "../Components/landing/LogoCloud";
import ProblemSolution from "../Components/landing/ProblemSolution";
import BenefitsGrid from "../Components/landing/BenefitsGrid";
import Testimonial from "../Components/landing/Testimonial";
import FinalCTA from "../Components/landing/FinalCTA";

export default function LandingPage() {
  const [scrolled, setScrolled] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-md' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68192c2d8b128ca183fad0a9/8136e6049_jobtize.jpeg" 
                alt="Jobtize" 
                className="h-10"
              />
            </div>
            <a 
              href="https://wa.me/5511987461094?text=Quero%20colocar%20minha%20empresa%20no%20futuro%20do%20recrutamento"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-[#FF6B35] to-[#FF8C42] text-white px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105"
            >
              Agendar Demo
            </a>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        <HeroSection />
        <LogoCloud />
        <ProblemSolution />
        <BenefitsGrid />
        <Testimonial />
        <FinalCTA />
      </main>

      {/* Footer */}
      <footer className="bg-[#2C3E50] text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68192c2d8b128ca183fad0a9/8136e6049_jobtize.jpeg" 
                alt="Jobtize" 
                className="h-8 brightness-0 invert"
              />
              <p className="text-sm text-gray-400 mt-2">O futuro do recrutamento é agora.</p>
            </div>
            <div className="text-sm text-gray-400">
              © 2025 Jobtize. Todos os direitos reservados.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
